package com.darknote.app

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.darknote.app.databinding.ActivitySettingsBinding
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    private val repository: NoteRepository by lazy {
        NoteRepository((application as NoteApp).database.noteDao())
    }

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
                // some providers may not support persistable permission; ignore
            }
            SettingsManager.setBackgroundImage(this, uri.toString())
            refreshBackground()
        }
    }

    private val restoreBackupLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            restoreFromBackup(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        refreshBackground()

        setupThemeSection()
        setupLanguageSection()
        setupBackgroundSection()
        setupBackupSection()

        binding.btnBack.setOnClickListener { finish() }
    }

    private fun setupThemeSection() {
        val current = SettingsManager.getThemeMode(this)
        when (current) {
            SettingsManager.THEME_LIGHT -> binding.radioLight.isChecked = true
            SettingsManager.THEME_DARK -> binding.radioDark.isChecked = true
            else -> binding.radioSystem.isChecked = true
        }

        binding.radioTheme.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                binding.radioLight.id -> SettingsManager.THEME_LIGHT
                binding.radioDark.id -> SettingsManager.THEME_DARK
                else -> SettingsManager.THEME_SYSTEM
            }
            SettingsManager.setThemeMode(this, mode)
        }
    }

    private fun setupLanguageSection() {
        val current = SettingsManager.getCurrentLanguage()
        if (current.startsWith("en")) {
            binding.radioEn.isChecked = true
        } else {
            binding.radioFa.isChecked = true
        }

        binding.radioLanguage.setOnCheckedChangeListener { _, checkedId ->
            val tag = when (checkedId) {
                binding.radioEn.id -> "en"
                else -> "fa"
            }
            SettingsManager.setLanguage(tag)
            // Locale change requires recreating the activity to apply new strings/RTL direction
            recreate()
        }
    }

    private fun setupBackgroundSection() {
        binding.rowColorSwatches.removeAllViews()
        val sizePx = (44 * resources.displayMetrics.density).toInt()
        val marginPx = (10 * resources.displayMetrics.density).toInt()

        for (hex in SettingsManager.presetColors) {
            val view = android.widget.FrameLayout(this)
            val params = android.widget.LinearLayout.LayoutParams(sizePx, sizePx)
            params.marginEnd = marginPx
            view.layoutParams = params

            val drawable = GradientDrawable()
            drawable.shape = GradientDrawable.OVAL
            drawable.setColor(Color.parseColor(hex))
            drawable.setStroke(
                (2 * resources.displayMetrics.density).toInt(),
                Color.parseColor("#66FFFFFF")
            )
            view.background = drawable

            val currentType = SettingsManager.getBackgroundType(this)
            val currentValue = SettingsManager.getBackgroundValue(this)
            if (currentType == SettingsManager.BG_TYPE_COLOR && currentValue.equals(hex, ignoreCase = true)) {
                val check = android.widget.ImageView(this)
                check.setImageResource(R.drawable.ic_check)
                val checkParams = android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
                )
                checkParams.gravity = android.view.Gravity.CENTER
                view.addView(check, checkParams)
            }

            view.setOnClickListener {
                SettingsManager.setBackgroundColor(this, hex)
                refreshBackground()
                setupBackgroundSection()
            }

            binding.rowColorSwatches.addView(view)
        }

        binding.btnChooseImage.setOnClickListener {
            pickImageLauncher.launch(arrayOf("image/*"))
        }

        binding.btnRemoveImage.setOnClickListener {
            SettingsManager.clearBackgroundImage(this)
            refreshBackground()
        }
    }

    private fun refreshBackground() {
        SettingsManager.applyBackground(this, binding.imgBackground)
        binding.root.post { LiquidGlassSource.updateFromView(binding.imgBackground) }
    }

    private fun setupBackupSection() {
        binding.btnBackupGmail.setOnClickListener {
            lifecycleScope.launch {
                val notes = repository.getAllNotesOnce()
                if (notes.isEmpty()) {
                    Toast.makeText(this@SettingsActivity, getString(R.string.backup_no_notes), Toast.LENGTH_SHORT).show()
                    return@launch
                }
                try {
                    val file = BackupManager.createBackupFile(this@SettingsActivity, notes)
                    val gmailIntent = BackupManager.buildGmailShareIntent(this@SettingsActivity, file)
                    if (gmailIntent != null) {
                        startActivity(gmailIntent)
                    } else {
                        Toast.makeText(
                            this@SettingsActivity,
                            getString(R.string.backup_gmail_not_found),
                            Toast.LENGTH_SHORT
                        ).show()
                        startActivity(BackupManager.buildGenericShareIntent(this@SettingsActivity, file))
                    }
                } catch (e: Exception) {
                    Toast.makeText(this@SettingsActivity, getString(R.string.restore_failed), Toast.LENGTH_SHORT).show()
                }
            }
        }

        binding.btnRestoreBackup.setOnClickListener {
            restoreBackupLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
        }
    }

    private fun restoreFromBackup(uri: android.net.Uri) {
        lifecycleScope.launch {
            try {
                val notes = BackupManager.parseBackupFile(this@SettingsActivity, uri)
                for (note in notes) {
                    repository.insert(note)
                }
                Toast.makeText(this@SettingsActivity, getString(R.string.restore_success), Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@SettingsActivity, getString(R.string.restore_failed), Toast.LENGTH_SHORT).show()
            }
        }
    }
}
