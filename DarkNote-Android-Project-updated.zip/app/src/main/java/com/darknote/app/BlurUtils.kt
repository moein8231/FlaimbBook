package com.darknote.app

import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.view.View
import androidx.annotation.RequiresApi

/**
 * Helper for applying a real backdrop blur to the background image on devices
 * that support it (Android 12 / API 31+, RenderEffect).
 *
 * On older devices (down to minSdk 24) this is a no-op: those screens keep the
 * existing translucent "frosted glass" fill + border look defined in the
 * bg_glass_* drawables, without a real optical blur.
 */
object BlurUtils {

    /** Default blur radius (in px) used for the app background. */
    private const val DEFAULT_BLUR_RADIUS = 42f

    /**
     * Applies a real Gaussian blur to [view] when running on Android 12+.
     * Safe to call on any API level; it simply does nothing below API 31.
     */
    fun applyBackdropBlur(view: View, radius: Float = DEFAULT_BLUR_RADIUS) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            applyBlurEffect(view, radius)
        }
    }

    @RequiresApi(Build.VERSION_CODES.S)
    private fun applyBlurEffect(view: View, radius: Float) {
        try {
            view.setRenderEffect(
                RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP)
            )
        } catch (e: Exception) {
            // If the view isn't hardware-accelerated for some reason, fail silently
            // and keep the non-blurred (but still translucent glass) background.
        }
    }

    /** Removes any previously applied blur effect. */
    fun clearBackdropBlur(view: View) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                view.setRenderEffect(null)
            } catch (e: Exception) {
                // ignore
            }
        }
    }
}
