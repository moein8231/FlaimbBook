package com.darknote.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.widget.LinearLayout
import com.google.android.material.color.MaterialColors

/**
 * A LinearLayout that renders itself as a "liquid glass" panel: a rounded,
 * bordered surface that shows a REAL blurred copy of whatever is behind it
 * (sampled from [LiquidGlassSource]) — while the actual app background stays
 * perfectly sharp. This is the same idea as iOS's Liquid Glass material:
 * the backdrop itself is never blurred, only the glass surfaces are.
 *
 * On very old devices, or before the first blur snapshot is ready, this
 * simply falls back to a plain translucent tint (no blur) so the UI never
 * looks broken.
 */
class GlassPanelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {

    private var topLeftRadius: Float
    private var topRightRadius: Float
    private var bottomLeftRadius: Float
    private var bottomRightRadius: Float
    private val showBorder: Boolean
    private val showSheen: Boolean

    private val path = Path()
    private val rect = RectF()
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }
    private val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val matrix = Matrix()
    private val loc = IntArray(2)

    init {
        val density = resources.displayMetrics.density
        val defaultRadius = 18f * density
        val ta = context.obtainStyledAttributes(attrs, R.styleable.GlassPanelView)
        val base = ta.getDimension(R.styleable.GlassPanelView_glassCornerRadius, defaultRadius)
        topLeftRadius = ta.getDimension(R.styleable.GlassPanelView_glassTopLeftRadius, base)
        topRightRadius = ta.getDimension(R.styleable.GlassPanelView_glassTopRightRadius, base)
        bottomLeftRadius = ta.getDimension(R.styleable.GlassPanelView_glassBottomLeftRadius, base)
        bottomRightRadius = ta.getDimension(R.styleable.GlassPanelView_glassBottomRightRadius, base)
        showBorder = ta.getBoolean(R.styleable.GlassPanelView_glassShowBorder, true)
        showSheen = ta.getBoolean(R.styleable.GlassPanelView_glassShowSheen, true)
        ta.recycle()

        setWillNotDraw(false)
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        LiquidGlassSource.register(this)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rect.set(0f, 0f, w.toFloat(), h.toFloat())
        rebuildPath()
    }

    private fun rebuildPath() {
        path.reset()
        val radii = floatArrayOf(
            topLeftRadius, topLeftRadius,
            topRightRadius, topRightRadius,
            bottomRightRadius, bottomRightRadius,
            bottomLeftRadius, bottomLeftRadius
        )
        path.addRoundRect(rect, radii, Path.Direction.CW)
    }

    override fun onDraw(canvas: Canvas) {
        val fillColor = MaterialColors.getColor(this, R.attr.appGlassFill, android.graphics.Color.GRAY)
        val borderColor = resolveBorderColor()

        canvas.save()
        canvas.clipPath(path)

        val bitmap = LiquidGlassSource.blurredBitmap
        if (bitmap != null && LiquidGlassSource.sourceWidth > 0 && LiquidGlassSource.sourceHeight > 0) {
            getLocationInWindow(loc)
            val bgLoc = LiquidGlassSource.backgroundLocationInWindow
            val relX = (loc[0] - bgLoc[0]).toFloat()
            val relY = (loc[1] - bgLoc[1]).toFloat()

            matrix.reset()
            matrix.setScale(
                LiquidGlassSource.sourceWidth.toFloat() / bitmap.width,
                LiquidGlassSource.sourceHeight.toFloat() / bitmap.height
            )
            canvas.translate(-relX, -relY)
            bitmapPaint.alpha = 255
            canvas.drawBitmap(bitmap, matrix, bitmapPaint)
            canvas.translate(relX, relY)
        }

        // Frosted tint on top of the (possibly blurred) backdrop.
        fillPaint.color = fillColor
        canvas.drawRect(rect, fillPaint)

        // Subtle top sheen for the "liquid glass" specular highlight.
        if (showSheen && rect.height() > 0) {
            sheenPaint.shader = LinearGradient(
                0f, 0f, 0f, rect.height() * 0.6f,
                0x33FFFFFF, 0x00FFFFFF,
                Shader.TileMode.CLAMP
            )
            canvas.drawRect(rect, sheenPaint)
        }

        canvas.restore()

        if (showBorder) {
            borderPaint.color = borderColor
            canvas.drawPath(path, borderPaint)
        }
    }

    private fun resolveBorderColor(): Int {
        return try {
            MaterialColors.getColor(this, R.attr.appGlassBorder, 0x4DFFFFFF)
        } catch (e: Exception) {
            0x4DFFFFFF
        }
    }
}
