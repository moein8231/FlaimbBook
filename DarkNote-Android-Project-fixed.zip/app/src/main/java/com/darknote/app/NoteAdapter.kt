package com.darknote.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.darknote.app.databinding.ItemNoteBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NoteAdapter(
    private val onClick: (Note) -> Unit,
    private val onLongClick: (Note) -> Unit,
    private val isSelected: (Long) -> Boolean,
    private val isSelectionMode: () -> Boolean
) : ListAdapter<Note, NoteAdapter.NoteViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val binding = ItemNoteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NoteViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class NoteViewHolder(private val binding: ItemNoteBinding) :
        RecyclerView.ViewHolder(binding.root) {

        private val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())

        fun bind(note: Note) {
            binding.textTitle.text = note.title.ifBlank { "بدون عنوان" }
            binding.textBody.text = note.body
            binding.textDate.text = dateFormat.format(Date(note.timestamp))

            val selected = isSelected(note.id)
            val selectionMode = isSelectionMode()

            binding.imgSelectedCheck.visibility = if (selected) View.VISIBLE else View.GONE
            binding.root.alpha = if (selectionMode && !selected) 0.55f else 1f

            binding.root.setOnClickListener {
                if (isSelectionMode()) onLongClick(note) else onClick(note)
            }
            binding.root.setOnLongClickListener {
                onLongClick(note)
                true
            }
        }
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Note>() {
            override fun areItemsTheSame(oldItem: Note, newItem: Note) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Note, newItem: Note) = oldItem == newItem
        }
    }
}
