package com.darknote.app

import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.darknote.app.databinding.ActivityNoteEditBinding
import kotlinx.coroutines.launch

class NoteEditActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNoteEditBinding
    private var currentNote: Note? = null

    private val repository: NoteRepository by lazy {
        NoteRepository((application as NoteApp).database.noteDao())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNoteEditBinding.inflate(layoutInflater)
        setContentView(binding.root)

        SettingsManager.applyBackground(this, binding.imgBackground)
        binding.root.post { LiquidGlassSource.updateFromView(binding.imgBackground) }

        val noteId = intent.getLongExtra(EXTRA_NOTE_ID, -1L)

        if (noteId != -1L) {
            lifecycleScope.launch {
                currentNote = repository.getById(noteId)
                currentNote?.let {
                    binding.editTitle.setText(it.title)
                    binding.editBody.setText(it.body)
                }
            }
            binding.btnDelete.visibility = android.view.View.VISIBLE
        } else {
            binding.btnDelete.visibility = android.view.View.GONE
        }

        binding.btnBack.setOnClickListener { saveAndFinish() }
        binding.btnSave.setOnClickListener { saveAndFinish() }

        binding.btnDelete.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.delete_confirm_title)
                .setMessage(R.string.delete_confirm_message)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete) { _, _ ->
                    currentNote?.let { note ->
                        lifecycleScope.launch {
                            repository.delete(note)
                            finish()
                        }
                    }
                }
                .show()
        }
    }

    private fun saveAndFinish() {
        val title = binding.editTitle.text.toString().trim()
        val body = binding.editBody.text.toString().trim()

        if (title.isEmpty() && body.isEmpty()) {
            finish()
            return
        }

        lifecycleScope.launch {
            val now = System.currentTimeMillis()
            val note = currentNote
            if (note == null) {
                repository.insert(Note(title = title, body = body, timestamp = now))
            } else {
                repository.update(note.copy(title = title, body = body, timestamp = now))
            }
            finish()
        }
    }

    companion object {
        const val EXTRA_NOTE_ID = "extra_note_id"
    }
}
