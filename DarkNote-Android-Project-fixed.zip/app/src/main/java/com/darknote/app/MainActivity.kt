package com.darknote.app

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.darknote.app.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: NoteAdapter
    private var allNotesCache: List<Note> = emptyList()

    private var selectionMode = false
    private val selectedIds = mutableSetOf<Long>()

    private val repository: NoteRepository by lazy {
        NoteRepository((application as NoteApp).database.noteDao())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = NoteAdapter(
            onClick = { note ->
                val intent = Intent(this, NoteEditActivity::class.java)
                intent.putExtra(NoteEditActivity.EXTRA_NOTE_ID, note.id)
                startActivity(intent)
            },
            onLongClick = { note -> toggleSelection(note) },
            isSelected = { id -> selectedIds.contains(id) },
            isSelectionMode = { selectionMode }
        )

        binding.recyclerNotes.layoutManager = GridLayoutManager(this, 2)
        binding.recyclerNotes.adapter = adapter
        val spacingPx = (12 * resources.displayMetrics.density).toInt()
        binding.recyclerNotes.addItemDecoration(GridSpacingItemDecoration(2, spacingPx))

        SettingsManager.applyBackground(this, binding.imgBackground)
        binding.root.post { LiquidGlassSource.updateFromView(binding.imgBackground) }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        repository.allNotes.observe(this) { notes ->
            allNotesCache = notes
            applyFilter(binding.editSearch.text.toString())
        }

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this, NoteEditActivity::class.java))
        }

        binding.editSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                applyFilter(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.btnCancelSelection.setOnClickListener { exitSelectionMode() }

        binding.btnDeleteSelected.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.delete_confirm_title)
                .setMessage(R.string.delete_selected_confirm_message)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete) { _, _ -> deleteSelectedNotes() }
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        SettingsManager.applyBackground(this, binding.imgBackground)
        binding.root.post { LiquidGlassSource.updateFromView(binding.imgBackground) }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (selectionMode) {
            exitSelectionMode()
        } else {
            super.onBackPressed()
        }
    }

    private fun applyFilter(query: String) {
        val filtered = if (query.isBlank()) {
            allNotesCache
        } else {
            allNotesCache.filter {
                it.title.contains(query, ignoreCase = true) || it.body.contains(query, ignoreCase = true)
            }
        }
        adapter.submitList(filtered)
        binding.emptyState.visibility = if (filtered.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    // ---- Multi-select for delete ----

    private fun toggleSelection(note: Note) {
        if (selectedIds.contains(note.id)) {
            selectedIds.remove(note.id)
        } else {
            selectedIds.add(note.id)
        }

        if (selectedIds.isEmpty()) {
            exitSelectionMode()
            return
        }

        selectionMode = true
        updateSelectionUi()
        adapter.notifyDataSetChanged()
    }

    private fun updateSelectionUi() {
        binding.selectionBar.visibility = android.view.View.VISIBLE
        binding.fabAdd.visibility = android.view.View.GONE
        binding.textSelectedCount.text = getString(R.string.selected_count_format, selectedIds.size)
    }

    private fun exitSelectionMode() {
        selectionMode = false
        selectedIds.clear()
        binding.selectionBar.visibility = android.view.View.GONE
        binding.fabAdd.visibility = android.view.View.VISIBLE
        adapter.notifyDataSetChanged()
    }

    private fun deleteSelectedNotes() {
        val toDelete = allNotesCache.filter { selectedIds.contains(it.id) }
        lifecycleScope.launch {
            toDelete.forEach { repository.delete(it) }
            exitSelectionMode()
        }
    }
}
