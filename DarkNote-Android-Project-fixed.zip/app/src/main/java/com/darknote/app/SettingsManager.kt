package com.darknote.app

import android.content.Context
import android.graphics.Color
import android.widget.ImageView
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

object SettingsManager {
    private const val PREFS_NAME = "darknote_settings"
    private const val KEY_THEME = "theme_mode"       // "light" | "dark" | "system"
    private const val KEY_BG_TYPE = "bg_type"        // "color" | "image"
    private const val KEY_BG_VALUE = "bg_value"      // color hex or image uri string
    private const val KEY_BLUR_ENABLED = "blur_enabled"

    const val THEME_LIGHT = "light"
    const val THEME_DARK = "dark"
    const val THEME_SYSTEM = "system"

    const val BG_TYPE_COLOR = "color"
    const val BG_TYPE_IMAGE = "image"

    val presetColors = listOf("#0E0F11", "#17181B", "#1F2937", "#2A2C30", "#3A3D42", "#D9BBA3")

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // ---- Theme ----
    fun getThemeMode(context: Context): String =
        prefs(context).getString(KEY_THEME, THEME_DARK) ?: THEME_DARK

    fun setThemeMode(context: Context, mode: String) {
        prefs(context).edit().putString(KEY_THEME, mode).apply()
        applyTheme(mode)
    }

    fun applyTheme(mode: String) {
        val nightMode = when (mode) {
            THEME_LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
            THEME_DARK -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(nightMode)
    }

    // ---- Language ----
    fun setLanguage(languageTag: String) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(languageTag))
    }

    fun getCurrentLanguage(): String {
        val locales = AppCompatDelegate.getApplicationLocales()
        return if (locales.isEmpty) "fa" else locales[0]?.language ?: "fa"
    }

    // ---- Background ----
    fun getBackgroundType(context: Context): String =
        prefs(context).getString(KEY_BG_TYPE, BG_TYPE_COLOR) ?: BG_TYPE_COLOR

    fun getBackgroundValue(context: Context): String =
        prefs(context).getString(KEY_BG_VALUE, "#17181B") ?: "#17181B"

    fun setBackgroundColor(context: Context, colorHex: String) {
        prefs(context).edit()
            .putString(KEY_BG_TYPE, BG_TYPE_COLOR)
            .putString(KEY_BG_VALUE, colorHex)
            .apply()
    }

    fun setBackgroundImage(context: Context, uri: String) {
        prefs(context).edit()
            .putString(KEY_BG_TYPE, BG_TYPE_IMAGE)
            .putString(KEY_BG_VALUE, uri)
            .apply()
    }

    fun clearBackgroundImage(context: Context) {
        prefs(context).edit()
            .putString(KEY_BG_TYPE, BG_TYPE_COLOR)
            .putString(KEY_BG_VALUE, "#17181B")
            .apply()
    }

    // ---- Glass blur effect ----
    /** Whether glass panels should show a real blurred backdrop (true) or a flat/transparent tint (false). */
    fun isBlurEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_BLUR_ENABLED, true)

    fun setBlurEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_BLUR_ENABLED, enabled).apply()
    }

    /** Applies the saved background (color or image) onto the given ImageView. */
    fun applyBackground(context: Context, imageView: ImageView) {
        val type = getBackgroundType(context)
        val value = getBackgroundValue(context)
        if (type == BG_TYPE_IMAGE) {
            try {
                imageView.scaleType = ImageView.ScaleType.CENTER_CROP
                imageView.setImageURI(android.net.Uri.parse(value))
                return
            } catch (e: Exception) {
                // fall through to color
            }
        }
        imageView.setImageDrawable(null)
        try {
            imageView.setBackgroundColor(Color.parseColor(value))
        } catch (e: Exception) {
            imageView.setBackgroundColor(Color.parseColor("#17181B"))
        }
    }
}
