package com.darknote.app

import android.graphics.Bitmap
import android.view.View
import androidx.core.view.drawToBitmap
import java.lang.ref.WeakReference

/**
 * Holds one shared, pre-blurred snapshot of the current background per
 * screen. [GlassPanelView] instances sample this bitmap (translated to their
 * own on-screen position) to render a real "liquid glass" blur behind
 * themselves — while the actual background the user sees stays perfectly
 * sharp.
 *
 * The blur is computed once whenever the background changes (not every
 * frame), so it stays cheap even though it's plain software blur.
 */
object LiquidGlassSource {

    private const val DOWNSAMPLE = 6 // render blur at 1/6th resolution: cheap + looks great
    private const val BLUR_RADIUS = 14

    var blurredBitmap: Bitmap? = null
        private set

    /** Size (in px) of the full-resolution view the blurred bitmap represents. */
    var sourceWidth: Int = 0
        private set
    var sourceHeight: Int = 0
        private set

    /** Location of the background view in window coordinates, at capture time. */
    val backgroundLocationInWindow: IntArray = intArrayOf(0, 0)

    private val listeners = mutableListOf<WeakReference<GlassPanelView>>()

    fun register(view: GlassPanelView) {
        listeners.removeAll { it.get() == null }
        listeners.add(WeakReference(view))
    }

    /**
     * Renders [backgroundView] (the full-screen background ImageView) into a
     * bitmap, blurs a downsampled copy, and notifies all registered glass
     * panels to redraw with the new snapshot.
     */
    fun updateFromView(backgroundView: View) {
        if (backgroundView.width <= 0 || backgroundView.height <= 0) return
        try {
            val full = backgroundView.drawToBitmap()
            sourceWidth = full.width
            sourceHeight = full.height
            backgroundView.getLocationInWindow(backgroundLocationInWindow)

            if (SettingsManager.isBlurEnabled(backgroundView.context)) {
                val smallW = maxOf(1, full.width / DOWNSAMPLE)
                val smallH = maxOf(1, full.height / DOWNSAMPLE)
                val small = Bitmap.createScaledBitmap(full, smallW, smallH, true)
                blurredBitmap = StackBlur.blur(small, BLUR_RADIUS)
            } else {
                // Blur disabled: glass panels fall back to their flat translucent
                // tint automatically (GlassPanelView handles a null bitmap gracefully).
                blurredBitmap = null
            }
        } catch (e: Exception) {
            // If we can't capture (e.g. view not laid out yet), leave the previous
            // snapshot in place; glass panels simply keep their translucent tint.
        }
        listeners.forEach { it.get()?.invalidate() }
    }
}
