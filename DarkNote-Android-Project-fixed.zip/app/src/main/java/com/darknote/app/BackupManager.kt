package com.darknote.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Handles exporting/importing notes as a JSON backup file and sharing that
 * file through the Gmail app as an email attachment.
 */
object BackupManager {

    private const val GMAIL_PACKAGE = "com.google.android.gm"

    /** Serializes all notes into a JSON backup file under the app's cache dir. */
    fun createBackupFile(context: Context, notes: List<Note>): File {
        val root = JSONObject()
        root.put("app", "DarkNote")
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        val array = JSONArray()
        for (note in notes) {
            val obj = JSONObject()
            obj.put("id", note.id)
            obj.put("title", note.title)
            obj.put("body", note.body)
            obj.put("timestamp", note.timestamp)
            array.put(obj)
        }
        root.put("notes", array)

        val backupDir = File(context.cacheDir, "backups").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(backupDir, "darknote_backup_$stamp.json")
        file.writeText(root.toString(2))
        return file
    }

    /** Parses a previously exported backup JSON file back into a list of Notes. */
    fun parseBackupFile(context: Context, uri: Uri): List<Note> {
        val text = context.contentResolver.openInputStream(uri)?.use { stream ->
            stream.bufferedReader().readText()
        } ?: throw IllegalArgumentException("empty file")

        val root = JSONObject(text)
        val array = root.optJSONArray("notes") ?: JSONArray()
        val result = mutableListOf<Note>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            result.add(
                Note(
                    id = 0, // always insert as new rows to avoid clobbering existing ids
                    title = obj.optString("title"),
                    body = obj.optString("body"),
                    timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                )
            )
        }
        return result
    }

    /**
     * Builds a share Intent for [file], targeted at Gmail specifically.
     * Returns null if Gmail isn't installed on the device.
     */
    fun buildGmailShareIntent(context: Context, file: File): Intent? {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_SUBJECT, "DarkNote Backup")
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            setPackage(GMAIL_PACKAGE)
        }

        val resolved = intent.resolveActivity(context.packageManager)
        return if (resolved != null) intent else null
    }

    /** Generic chooser fallback (any email/share target) when Gmail isn't installed. */
    fun buildGenericShareIntent(context: Context, file: File): Intent {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_SUBJECT, "DarkNote Backup")
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(intent, "ارسال بکاپ")
    }
}
