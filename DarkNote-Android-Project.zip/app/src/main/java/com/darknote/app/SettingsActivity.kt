package com.darknote.app

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.darknote.app.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
                // some providers may not support persistable permission; ignore
            }
            SettingsManager.setBackgroundImage(this, uri.toString())
            SettingsManager.applyBackground(this, binding.imgBackground)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        SettingsManager.applyBackground(this, binding.imgBackground)

        setupThemeSection()
        setupLanguageSection()
        setupBackgroundSection()

        binding.btnBack.setOnClickListener { finish() }
    }

    private fun setupThemeSection() {
        val current = SettingsManager.getThemeMode(this)
        when (current) {
            SettingsManager.THEME_LIGHT -> binding.radioLight.isChecked = true
            SettingsManager.THEME_DARK -> binding.radioDark.isChecked = true
            else -> binding.radioSystem.isChecked = true
        }

        binding.radioTheme.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                binding.radioLight.id -> SettingsManager.THEME_LIGHT
                binding.radioDark.id -> SettingsManager.THEME_DARK
                else -> SettingsManager.THEME_SYSTEM
            }
            SettingsManager.setThemeMode(this, mode)
        }
    }

    private fun setupLanguageSection() {
        val current = SettingsManager.getCurrentLanguage()
        if (current.startsWith("en")) {
            binding.radioEn.isChecked = true
        } else {
            binding.radioFa.isChecked = true
        }

        binding.radioLanguage.setOnCheckedChangeListener { _, checkedId ->
            val tag = when (checkedId) {
                binding.radioEn.id -> "en"
                else -> "fa"
            }
            SettingsManager.setLanguage(tag)
            // Locale change requires recreating the activity to apply new strings/RTL direction
            recreate()
        }
    }

    private fun setupBackgroundSection() {
        binding.rowColorSwatches.removeAllViews()
        val sizePx = (44 * resources.displayMetrics.density).toInt()
        val marginPx = (10 * resources.displayMetrics.density).toInt()

        for (hex in SettingsManager.presetColors) {
            val view = android.widget.FrameLayout(this)
            val params = android.widget.LinearLayout.LayoutParams(sizePx, sizePx)
            params.marginEnd = marginPx
            view.layoutParams = params

            val drawable = GradientDrawable()
            drawable.shape = GradientDrawable.OVAL
            drawable.setColor(Color.parseColor(hex))
            drawable.setStroke(
                (2 * resources.displayMetrics.density).toInt(),
                Color.parseColor("#66FFFFFF")
            )
            view.background = drawable

            val currentType = SettingsManager.getBackgroundType(this)
            val currentValue = SettingsManager.getBackgroundValue(this)
            if (currentType == SettingsManager.BG_TYPE_COLOR && currentValue.equals(hex, ignoreCase = true)) {
                val check = android.widget.ImageView(this)
                check.setImageResource(R.drawable.ic_check)
                val checkParams = android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
                )
                checkParams.gravity = android.view.Gravity.CENTER
                view.addView(check, checkParams)
            }

            view.setOnClickListener {
                SettingsManager.setBackgroundColor(this, hex)
                SettingsManager.applyBackground(this, binding.imgBackground)
                setupBackgroundSection()
            }

            binding.rowColorSwatches.addView(view)
        }

        binding.btnChooseImage.setOnClickListener {
            pickImageLauncher.launch(arrayOf("image/*"))
        }

        binding.btnRemoveImage.setOnClickListener {
            SettingsManager.clearBackgroundImage(this)
            SettingsManager.applyBackground(this, binding.imgBackground)
        }
    }
}
