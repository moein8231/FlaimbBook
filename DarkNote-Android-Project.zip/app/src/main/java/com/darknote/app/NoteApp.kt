package com.darknote.app

import android.app.Application

class NoteApp : Application() {
    val database: NoteDatabase by lazy { NoteDatabase.getInstance(this) }
}
