package com.darknote.app

import android.app.Application

class NoteApp : Application() {
    val database: NoteDatabase by lazy { NoteDatabase.getInstance(this) }

    override fun onCreate() {
        super.onCreate()
        SettingsManager.applyTheme(SettingsManager.getThemeMode(this))
    }
}
