package com.darknote.app

import androidx.lifecycle.LiveData

class NoteRepository(private val dao: NoteDao) {

    val allNotes: LiveData<List<Note>> = dao.getAllNotes()

    suspend fun insert(note: Note): Long = dao.insert(note)

    suspend fun update(note: Note) = dao.update(note)

    suspend fun delete(note: Note) = dao.delete(note)

    suspend fun getById(id: Long): Note? = dao.getById(id)
}
