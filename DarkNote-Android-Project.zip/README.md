# Flaim book (نسخه ۲)

اپلیکیشن اندروید دفترچه یادداشت، نوشته‌شده با Kotlin.

## ویژگی‌های نسخه جدید
- افکت شیشه‌ای (Liquid Glass) روی نوار بالا، نوار جستجو، کارت یادداشت‌ها و کادر ویرایش
- پس‌زمینه قابل تنظیم: چند رنگ آماده یا انتخاب عکس دلخواه از گالری
- حالت روشن / تیره / پیش‌فرض سیستم (از صفحه تنظیمات قابل تغییره)
- پشتیبانی دو زبانه فارسی و انگلیسی (از صفحه تنظیمات قابل تغییره)
- افزودن، ویرایش، حذف و جستجوی یادداشت با ذخیره‌سازی محلی (Room Database)

نسخه package name (applicationId) یکسان با نسخه قبلی نگه داشته شده (`com.darknote.app`)، پس اگه APK قبلی رو نصب داشته باشید، این نسخه به‌جای نصب جداگانه، به‌صورت **آپدیت** جایگزین میشه و یادداشت‌های قبلی پاک نمی‌شن.

## نحوه ساخت APK

### روش ۱: Android Studio
1. [Android Studio](https://developer.android.com/studio) را نصب کنید.
2. پوشه پروژه را باز کنید: File > Open.
3. صبر کنید Gradle Sync تمام شود.
4. از منو: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. فایل APK: `app/build/outputs/apk/debug/app-debug.apk`

### روش ۲: خط فرمان
```
cd DarkNote
./gradlew assembleDebug
```

### روش ۳: بدون کامپیوتر (GitHub Actions)
یک فایل `.github/workflows/build.yml` توی پروژه هست که به‌صورت خودکار روی سرورهای گیت‌هاب APK رو می‌سازه. کافیه پروژه رو به یک Repository در گیت‌هاب push/آپلود کنید و از تب Actions فایل خروجی رو دانلود کنید.

## ساخت نسخه امضاشده برای انتشار (Release APK)
1. در Android Studio: Build > Generate Signed Bundle / APK
2. یک Keystore جدید بسازید یا از قبلی استفاده کنید
3. APK امضا‌شده (release) تولید می‌شود

## ساختار پروژه
```
app/src/main/java/com/darknote/app/
├── NoteApp.kt            — کلاس Application (اعمال تم در استارتاپ)
├── Note.kt                — مدل داده (Room Entity)
├── NoteDao.kt              — عملیات دیتابیس
├── NoteDatabase.kt         — تعریف دیتابیس Room
├── NoteRepository.kt       — لایه دسترسی به داده
├── NoteAdapter.kt          — آداپتور لیست یادداشت‌ها
├── SettingsManager.kt      — مدیریت تم، زبان، پس‌زمینه (SharedPreferences)
├── MainActivity.kt         — صفحه اصلی (لیست یادداشت‌ها + جستجو)
├── NoteEditActivity.kt     — صفحه افزودن/ویرایش یادداشت
└── SettingsActivity.kt     — صفحه تنظیمات
```

## نکته درباره افکت شیشه‌ای
افکت لیکویید گلس با ترکیب رنگ‌های نیمه‌شفاف، حاشیه نورانی و گرادینت پیاده‌سازی شده (بدون کتابخانه‌ی خارجی) تا ساخت پروژه پایدار و بدون وابستگی اضافه بمونه.
