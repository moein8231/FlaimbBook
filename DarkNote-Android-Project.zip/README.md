# دفترچه یادداشت (DarkNote)

اپلیکیشن اندروید دفترچه یادداشت با تم طوسی تیره و مشکی، نوشته‌شده با Kotlin.

## ویژگی‌ها
- افزودن، ویرایش و حذف یادداشت
- جستجو در یادداشت‌ها
- ذخیره‌سازی محلی با Room Database (اطلاعات بدون نیاز به اینترنت ذخیره می‌شوند)
- تم کاملاً طوسی تیره / مشکی با رنگ تاکیدی بژ (هماهنگ با آیکون)
- آیکون اپلیکیشن بر اساس تصویری که ارسال کردید ساخته شده

## نحوه ساخت APK

### روش ۱: Android Studio (پیشنهادی)
1. [Android Studio](https://developer.android.com/studio) را نصب کنید.
2. پوشه پروژه (`DarkNote`) را باز کنید: File > Open > مسیر پوشه پروژه.
3. صبر کنید تا Gradle Sync تمام شود (اینترنت لازم است تا وابستگی‌ها دانلود شوند).
4. از منو: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. فایل APK در مسیر زیر ساخته می‌شود:
   `app/build/outputs/apk/debug/app-debug.apk`

### روش ۲: خط فرمان (Terminal)
اگر Android SDK و JDK 17 نصب دارید:

```
cd DarkNote
./gradlew assembleDebug
```

فایل خروجی در همان مسیر بالا قرار می‌گیرد.

## ساخت نسخه امضاشده برای انتشار (Release APK)
برای انتشار در گوشی‌های دیگر یا Google Play باید APK را امضا کنید:
1. در Android Studio: Build > Generate Signed Bundle / APK
2. یک Keystore جدید بسازید یا از قبلی استفاده کنید
3. APK امضا‌شده (release) تولید می‌شود

## ساختار پروژه
```
app/src/main/java/com/darknote/app/
├── NoteApp.kt          — کلاس Application
├── Note.kt              — مدل داده (Room Entity)
├── NoteDao.kt            — عملیات دیتابیس
├── NoteDatabase.kt       — تعریف دیتابیس Room
├── NoteRepository.kt     — لایه دسترسی به داده
├── NoteAdapter.kt        — آداپتور لیست یادداشت‌ها
├── MainActivity.kt       — صفحه اصلی (لیست یادداشت‌ها + جستجو)
└── NoteEditActivity.kt   — صفحه افزودن/ویرایش یادداشت
```

## نکته درباره آیکون
آیکون اپلیکیشن (adaptive icon) از تصویری که فرستادید تولید شده و در تمام دقت‌های لازم (mdpi تا xxxhdpi) قرار داده شده است.
